import torch
import torch.nn as nn
from dgl.sampling import random_walk
from graphwar.utils import remove_edges

class DropPath(nn.Module):
    def __init__(self, p=0.5, length=3, num_walks=3):
        super().__init__()
        self.p = p
        self.length = length
        self.num_walks = num_walks
        
    def forward(self, g, starts=None):
        if not self.training or not self.p:
            return g
        
        g = g.local_var()
        num_nodes = g.num_nodes()
    
        num_starts = int(self.p * num_nodes)
        starts = torch.randperm(num_nodes)[:num_starts]
        starts = starts.repeat(self.num_walks)

        e_ids = random_walk(g.to('cpu'), starts.cpu(), length=self.length, return_eids=True)[1].view(-1)
        # e_ids = node2vec_random_walk(g.to('cpu'), starts.cpu(), 1, 1, self.length, return_eids=True)[1].view(-1)
        
#         g.remove_edges(e_ids.to(g.device))
#         return g.add_self_loop()
        return remove_edges(g, e_ids.to(g.device))
    
    def extra_repr(self) -> str:
        return f"p={self.p}"
            
        

class DropEdge(nn.Module):
    def __init__(self, p=0.5):
        super().__init__()
        self.p = p
    def forward(self, g, starts=None):
        if not self.training or not self.p:
            return g
        g = g.remove_self_loop()
        num_edges = g.num_edges()
        num_dels = int(self.p * num_edges)
        e_ids = torch.randperm(num_edges)[:num_dels]
        

        g.remove_edges(e_ids.to(g.device))
        
        return g.add_self_loop()
    
    def extra_repr(self) -> str:
        return f"p={self.p}"    
        